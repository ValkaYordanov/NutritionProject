﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NutritionApp.Models.ViewModels
{
    public class BasketIndexViewModel
    {
        public Basket Basket { get; set; }
        public Meal Meal { get; set; }
    }
}
